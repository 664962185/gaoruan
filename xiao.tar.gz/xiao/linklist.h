/*************************************************************************************************/
/* Copyright (C) mc2lab.com, SSE@USTC, 2014-2015                                                 */
/*                                                                                               */
/* FILE NAME               :  linklist.h                                                         */
/* PRINCIPAL AUTHOR        :  Xiaoyong                                                           */
/* SUBSYSTEM NAME          :  link                                                               */
/* MODULE NAME             :  link                                                               */
/* LANGUAGE                :  C                                                                  */
/* TARGET ENVIRONMENT      :  ANY                                                                */
/* DATE OF FIRST RELEASE   :  2014/09/18                                                         */
/* DESCRIPTION             :  This is a menu program                                             */
/*************************************************************************************************/

/*
 * Revision log;
 * Created by Xiaoyong, 2014/09/12
 *
 */

#ifndef _LINKLIST_H_
#define _LINKLIST_H_

#include <pthread.h>

#define SUCCESS 1
#define FAILURE 0

/*
 * LinkList Node Type
 */
typedef struct LinkListNode
{
    struct LinkListNode * pNext;
}tLinkListNode;

/*
 * LinkList Type
 */
typedef struct LinkList tLinkList;

/*
 * Create a LinkList
 */
tLinkList * CreateLinkList();
/*
 * Delete a LinkList
 */
int DeleteLinkList(tLinkList *pLinkList);
/*
 * Add a LinkListNode to LinkList
 */
int AddLinkListNode(tLinkList *pLinkList,tLinkListNode * pNode);
/*
 * Delete a LinkListNode from LinkList
 */
int DelLinkListNode(tLinkList *pLinkList,tLinkListNode * pNode);
/*
 * Search a LinkListNode from LinkList
 * int Conditon(tLinkListNode * pNode);
 */
tLinkListNode * SearchLinkListNode(tLinkList *pLinkList, int Conditon(tLinkListNode * pNode));
/*
 * get LinkListHead
 */
tLinkListNode * GetLinkListHead(tLinkList *pLinkList);
/*
 * get next LinkListNode
 */
tLinkListNode * GetNextLinkListNode(tLinkList *pLinkList,tLinkListNode * pNode);

int Help();

int Quit();

#endif /* _LINKLIST_H_ */



