/*************************************************************************************************/
/* Copyright (C) mc2lab.com, SSE@USTC, 2014-2015                                                 */
/*                                                                                               */
/* FILE NAME               :  testmenu.c                                                         */
/* PRINCIPAL AUTHOR        :  Xiaoyong                                                           */
/* SUBSYSTEM NAME          :  test                                                               */
/* MODULE NAME             :  test                                                               */
/* LANGUAGE                :  C                                                                  */
/* TARGET ENVIRONMENT      :  ANY                                                                */
/* DATE OF FIRST RELEASE   :  2014/09/18                                                         */
/* DESCRIPTION             :  This is a menu program                                             */
/*************************************************************************************************/

/*
 * Revision log;
 * Created by Xiaoyong, 2014/09/12
 *
 */

#include <stdio.h>
#include "menu.h"


int main()
{

    InitMenu();
    ShowAllCmd();
    InsertCmd("ps", "This is ps command!", NULL);  
    ShowAllCmd();
    ExecuteMenu();      
            
    return 0;
}

