This is a testmenu program!

Build Procedure
    $ gcc linklist.c menu.c testmenu.c -o testmenu
    $ ./testmenu  

or  $ makefile
    $./testmenu

!!!