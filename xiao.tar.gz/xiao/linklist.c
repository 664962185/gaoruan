/*************************************************************************************************/
/* Copyright (C) mc2lab.com, SSE@USTC, 2014-2015                                                 */
/*                                                                                               */
/* FILE NAME               :  link.c                                                             */
/* PRINCIPAL AUTHOR        :  Xiaoyong                                                           */
/* SUBSYSTEM NAME          :  link                                                               */
/* MODULE NAME             :  link                                                               */
/* LANGUAGE                :  C                                                                  */
/* TARGET ENVIRONMENT      :  ANY                                                                */
/* DATE OF FIRST RELEASE   :  2014/09/18                                                         */
/* DESCRIPTION             :  This is a menu program                                             */
/*************************************************************************************************/

/*
 * Revision log;
 * Created by Xiaoyong, 2014/09/12
 *
 */

#include<stdio.h>
#include<stdlib.h>

#include"linklist.h"

/*
 * LinkList Type
 */
struct LinkList
{
    tLinkListNode *pHead;
    tLinkListNode *pTail;
    int    SumOfNode;
    pthread_mutex_t mutex;
};

/*
 * Create a LinkList
 */
tLinkList * CreateLinkList()
{
    tLinkList * pLinkList = (tLinkList *)malloc(sizeof(tLinkList));
    if(pLinkList == NULL)
    {
        return NULL;
    }
    pLinkList->pHead = NULL;
    pLinkList->pTail = NULL;
    pLinkList->SumOfNode = 0;
    pthread_mutex_init(&(pLinkList->mutex), NULL);
    return pLinkList;
}
/*
 * Delete a LinkList
 */
int DeleteLinkList(tLinkList *pLinkList)
{
    if(pLinkList == NULL)
    {
        return FAILURE;
    }
    while(pLinkList->pHead != NULL)
    {
        tLinkListNode * p = pLinkList->pHead;
        pthread_mutex_lock(&(pLinkList->mutex));
        pLinkList->pHead = pLinkList->pHead->pNext;
        pLinkList->SumOfNode -= 1 ;
        pthread_mutex_unlock(&(pLinkList->mutex));
        free(p);
    }
    pLinkList->pHead = NULL;
    pLinkList->pTail = NULL;
    pLinkList->SumOfNode = 0;
    pthread_mutex_destroy(&(pLinkList->mutex));
    free(pLinkList);
    return SUCCESS;        
}
/*
 * Add a LinkListNode to LinkList
 */
int AddLinkListNode(tLinkList *pLinkList,tLinkListNode * pNode)
{
    if(pLinkList == NULL || pNode == NULL)
    {
        return FAILURE;
    }
    pNode->pNext = NULL;
    pthread_mutex_lock(&(pLinkList->mutex));
    if(pLinkList->pHead == NULL)
    {
        pLinkList->pHead = pNode;
    }
    if(pLinkList->pTail == NULL)
    {
        pLinkList->pTail = pNode;
    }
    else
    {
        pLinkList->pTail->pNext = pNode;
        pLinkList->pTail = pNode;
    }
    pLinkList->SumOfNode += 1 ;
    pthread_mutex_unlock(&(pLinkList->mutex));
    return SUCCESS;        
}
/*
 * Delete a LinkListNode from LinkList
 */
int DelLinkListNode(tLinkList *pLinkList,tLinkListNode * pNode)
{
    if(pLinkList == NULL || pNode == NULL)
    {
        return FAILURE;
    }
    pthread_mutex_lock(&(pLinkList->mutex));
    if(pLinkList->pHead == pNode)
    {
        pLinkList->pHead = pLinkList->pHead->pNext;
        pLinkList->SumOfNode -= 1 ;
        if(pLinkList->SumOfNode == 0)
        {
            pLinkList->pTail = NULL;    
        }
        pthread_mutex_unlock(&(pLinkList->mutex));
        return SUCCESS;
    }
    tLinkListNode * pTempNode = pLinkList->pHead;
    while(pTempNode != NULL)
    {    
        if(pTempNode->pNext == pNode)
        {
            pTempNode->pNext = pTempNode->pNext->pNext;
            pLinkList->SumOfNode -= 1 ;
            if(pLinkList->SumOfNode == 0)
            {
                pLinkList->pTail = NULL;    
            }
            pthread_mutex_unlock(&(pLinkList->mutex));
            return SUCCESS;                    
        }
        pTempNode = pTempNode->pNext;
    }
    pthread_mutex_unlock(&(pLinkList->mutex));
    return FAILURE;        
}

/*
 * Search a LinkListNode from LinkList
 * int Conditon(tLinkListNode * pNode);
 */
tLinkListNode * SearchLinkListNode(tLinkList *pLinkList, int Conditon(tLinkListNode * pNode))
{
    if(pLinkList == NULL || Conditon == NULL)
    {
        return NULL;
    }
    tLinkListNode * pNode = pLinkList->pHead;
    while(pNode != pLinkList->pTail)
    {    
        if(Conditon(pNode) == SUCCESS)
        {
            return pNode;                    
        }
        pNode = pNode->pNext;
    }
    return NULL;
}

/*
 * get LinkListHead
 */
tLinkListNode * GetLinkListHead(tLinkList *pLinkList)
{
    if(pLinkList == NULL)
    {
        return NULL;
    }    
    return pLinkList->pHead;
}

/*
 * get next LinkListNode
 */
tLinkListNode * GetNextLinkListNode(tLinkList *pLinkList,tLinkListNode * pNode)
{
    if(pLinkList == NULL || pNode == NULL)
    {
        return NULL;
    }
    tLinkListNode * pTempNode = pLinkList->pHead;
    while(pTempNode != NULL)
    {    
        if(pTempNode == pNode)
        {
            return pTempNode->pNext;                    
        }
        pTempNode = pTempNode->pNext;
    }
    return NULL;
}


int Help()
{
    ShowAllCmd();
    return 0; 
}

int Quit()
{
    exit(0);
}


