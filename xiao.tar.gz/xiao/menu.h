/*************************************************************************************************/
/* Copyright (C) mc2lab.com, SSE@USTC, 2014-2015                                                 */
/*                                                                                               */
/* FILE NAME               :  menu.h                                                             */
/* PRINCIPAL AUTHOR        :  Xiaoyong                                                           */
/* SUBSYSTEM NAME          :  menu                                                               */
/* MODULE NAME             :  menu                                                               */
/* LANGUAGE                :  C                                                                  */
/* TARGET ENVIRONMENT      :  ANY                                                                */
/* DATE OF FIRST RELEASE   :  2014/09/18                                                         */
/* DESCRIPTION             :  This is a menu program                                             */
/*************************************************************************************************/

/*
 * Revision log;
 * Created by Xiaoyong, 2014/09/12
 *
 */

#ifndef _MENU_H_
#define _MENU_H_

#include "linklist.h"

#define CMD_MAX_LEN 128

/* MenuNode Declaration */
typedef struct MenuNode tMenuNode;

/* Initiate a menu with useful internal cmd */
int InitMenu();

/* Search a cmd by cmd name */
tMenuNode* SearchCmd(char *cmd);

/* Show all the cmds of the menu */
int ShowAllCmd();
 
/* Insert a cmd */
int InsertCmd(char* cmd, char* desc, int (*handler)());

/* Delete a cmd by cmd name*/
int DelCmd(char* cmd);


/* Execute the menu */
int ExecuteMenu();

#endif
